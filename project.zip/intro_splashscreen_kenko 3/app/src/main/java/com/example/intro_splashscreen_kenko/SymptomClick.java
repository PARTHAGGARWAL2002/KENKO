package com.example.intro_splashscreen_kenko;

public interface SymptomClick {
    void onclick(int position);
}

