package com.example.intro_splashscreen_kenko;

import com.google.gson.annotations.SerializedName;

public class specialistoutput {
    @SerializedName("recommended_specialist")
    private RecommendedSpecialist recommendedSpecialist;
    @SerializedName("recommended_channel")
    private String recommendedChannel;

    public RecommendedSpecialist getRecommendedSpecialist() {
        return recommendedSpecialist;
    }

    public void setRecommendedSpecialist(RecommendedSpecialist recommendedSpecialist) {
        this.recommendedSpecialist = recommendedSpecialist;
    }

    public String getRecommendedChannel() {
        return recommendedChannel;
    }

    public void setRecommendedChannel(String recommendedChannel) {
        this.recommendedChannel = recommendedChannel;
    }

}
 class RecommendedSpecialist {
    @SerializedName("id")
    private String id;
    @SerializedName("name")
    private String naame;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNaame() {
        return naame;
    }

    public void setNaame(String name) {
        this.naame = naame;
    }

}
