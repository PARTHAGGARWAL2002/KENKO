package com.example.intro_splashscreen_kenko;


import com.google.gson.annotations.SerializedName;

import java.util.List;

public class DiagnosisOutput {
    @SerializedName("question")
    Question question;
    @SerializedName("conditions")
    List<Conditions> conditions;
    @SerializedName("should_stop")
    Boolean shouldStop;

}

class Question {
    @SerializedName("type")
    String type;
    @SerializedName("text")
    String text;
    @SerializedName("items")
    List<QuestionItem> items;
}

class Conditions {
    @SerializedName("id")
    String id;
    @SerializedName("name")
    String name;
    @SerializedName("common_name")
    String common_name;
    @SerializedName("probability")
    double probability;
    @SerializedName("condition_details")
    Condition_details condition_details;

}

class QuestionItem{
    @SerializedName("id")
    String id;
    @SerializedName("name")
    String name;
    @SerializedName("choices")
    List<ChoiceItem> choice;
}

class ChoiceItem {
    @SerializedName("id")
    String id;
    @SerializedName("label")
    String label;
}
class Condition_details{
    @SerializedName("icd10_code")
    String icd10_code;
    @SerializedName("category")
    Cat category;
    @SerializedName("prevalence")
    String prevalence;
    @SerializedName("severity")
    String severity;
    @SerializedName("acuteness")
    String acuteness;
    @SerializedName("triage_level")
    String triage_level;
    @SerializedName("hint")
    String hint;
}
class Cat{
    @SerializedName("id")
    String id;
    @SerializedName("name")
    String name;
}