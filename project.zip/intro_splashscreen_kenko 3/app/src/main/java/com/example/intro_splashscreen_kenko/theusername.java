package com.example.intro_splashscreen_kenko;

public class theusername {
    private String username;

    public theusername(String s) {
    }

    public void assignname(String s) {
        username=s;
    }
    public String give(){
        return username;
    }

}
