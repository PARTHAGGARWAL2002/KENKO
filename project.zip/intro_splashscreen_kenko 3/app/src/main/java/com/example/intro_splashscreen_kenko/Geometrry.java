package com.example.intro_splashscreen_kenko;


import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Geometrry implements Serializable {

    @SerializedName("location")
    private Locaation locaation;

    public Locaation getLocaation() {
        return locaation;
    }

    public void setLocaation(Locaation locaation) {
        this.locaation = locaation;
    }

}
