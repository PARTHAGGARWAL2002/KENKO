package com.example.intro_splashscreen_kenko;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class DiagnosisInput {
    @SerializedName("sex")
    String sex;
    @SerializedName("age")
    Age age;
    @SerializedName("evidence")
    List<EvidenceItem> evidenceItems;
    @SerializedName("extras")
    Extra extra;

    public DiagnosisInput(String sex, Age age, List<EvidenceItem> evidenceItems, Extra extra) {
        this.sex = sex;
        this.age = age;
        this.evidenceItems = evidenceItems;
        this.extra = extra;
    }
}

class Age {
    @SerializedName("value")
    int value;

    public Age(int value) {
        this.value = value;
    }
}

class EvidenceItem {
    @SerializedName("id")
    String id;
    @SerializedName("choice_id")
    String choice;
    @SerializedName("source")
    String source;

    public EvidenceItem(String id, String choice, String source) {
        this.id = id;
        this.choice = choice;
        this.source = source;
    }
}
class Extra{
    @SerializedName("include_condition_details")
    Boolean include_condition_details;

    public Extra(Boolean include_condition_details){
        this.include_condition_details = include_condition_details;
    }
}
