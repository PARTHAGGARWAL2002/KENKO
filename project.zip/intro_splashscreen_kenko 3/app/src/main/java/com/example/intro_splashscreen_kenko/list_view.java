package com.example.intro_splashscreen_kenko;

public class list_view {
    private String heading;

    public list_view(String heading) {
        this.heading = heading;
    }

    public String getHeading() {
        return heading;
    }
}
