package com.example.intro_splashscreen_kenko;


import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import org.jetbrains.annotations.NotNull;

import java.io.Serializable;
import java.util.List;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;

public class adapter extends RecyclerView.Adapter<adapter.MyViewHolder> {
    Context context;
    private List<Results> results;
    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.place_row_layout,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull MyViewHolder holder, int position) {
        Results result = results.get(position);
        holder.name.setText(result.getName().toUpperCase());
        holder.Address.setText(result.getVicinity());
        if(result.getRating()<0.5)
            holder.img.setImageResource(R.drawable.star0);
        else if(result.getRating()<1.5)
            holder.img.setImageResource(R.drawable.star1);
        else if(result.getRating()<2.5)
            holder.img.setImageResource(R.drawable.star2);
        else if(result.getRating()<3.5)
            holder.img.setImageResource(R.drawable.star3);
        else if(result.getRating()<4.3)
            holder.img.setImageResource(R.drawable.star4);
        else if(result.getRating()<4.7&& result.getRating()>=4.3)
            holder.img.setImageResource(R.drawable.star4_5);
        else
            holder.img.setImageResource(R.drawable.star5);
        String loc = result.getGeometrry().getLocaation().getLat()+","+result.getGeometrry().getLocaation().getLng();
        Log.e("a",loc);

        holder.ratno.setText(result.getRating().toString());
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context,testactivity.class);
                intent.addFlags(FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("placeid", result.getPlaceId());
                intent.putExtra("loc",loc);
                intent.putExtra("status",result.getPriceLevel());
                context.startActivity(intent);
            }
        });
        //   Log.e("yo",result.getPhotos().get(position).getPhotoReference());
//        Glide.with(context)
//                .load("https://maps.googleapis.com/maps/api/place/photo?maxwidth=70&photoreference="+result.getPhotos().get(position).getPhotoReference())
//                .into(holder.imgrat);
    }

    @Override
    public int getItemCount() {
        return results.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView name;
        TextView Address;
        ImageView img;
        ImageView imgrat;
        TextView ratno;
        LinearLayout linearLayout;
        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
//            itemView.setOnClickListener((View.OnClickListener) this);
            name = itemView.findViewById(R.id.textViewName);
            Address = itemView.findViewById(R.id.textViewAddress);
            imgrat = itemView.findViewById(R.id.imageViewPhoto);
            ratno = itemView.findViewById(R.id.ratingno);
            img = itemView.findViewById(R.id.rating);
            linearLayout = (LinearLayout) itemView.findViewById(R.id.linearlayout);

        }
    }
    public adapter(Context ctx, List<Results> result){
        context=ctx;
        results=result;

    }

}
