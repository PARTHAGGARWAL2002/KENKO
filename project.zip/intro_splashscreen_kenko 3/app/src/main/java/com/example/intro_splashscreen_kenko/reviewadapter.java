package com.example.intro_splashscreen_kenko;


import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class reviewadapter extends RecyclerView.Adapter<reviewadapter.MyViewHolder> {
    Context context;
    private List<Review> revieww;

    public reviewadapter(Context applicationContext, List<Review> reviews) {
        context = applicationContext;
//        Log.e("reviw",reviews.size() +"");
        revieww  = reviews;
    }

    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.review_layout, parent, false);
        return new reviewadapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull MyViewHolder holder, int position) {
        Review re = revieww.get(position);
        Log.e("review",re.getAuthorName());
        holder.name.setText(re.getAuthorName());
        holder.text.setText(re.getText());
        holder.ratno.setText(re.getRating().toString());
        if(re.getRating()<0.5)
            holder.imgrat.setImageResource(R.drawable.star0);
        else if(re.getRating()<1.5)
            holder.imgrat.setImageResource(R.drawable.star1);
        else if(re.getRating()<2.5)
            holder.imgrat.setImageResource(R.drawable.star2);
        else if(re.getRating()<3.5)
            holder.imgrat.setImageResource(R.drawable.star3);
        else if(re.getRating()<4.3)
            holder.imgrat.setImageResource(R.drawable.star4);
        else if(re.getRating()<4.7&& re.getRating()>=4.3)
            holder.imgrat.setImageResource(R.drawable.star4_5);
        else
            holder.imgrat.setImageResource(R.drawable.star5);
        Glide.with(context).load(re.getProfilePhotoUrl()).circleCrop().into(holder.img);
    }

    @Override
    public int getItemCount() {
        return revieww.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        TextView text;
        ImageView img;
        ImageView imgrat;
        TextView ratno;
        public MyViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            name = (TextView)itemView.findViewById(R.id.reviewerName);
            text = itemView.findViewById(R.id.reviewtext);
            imgrat = itemView.findViewById(R.id.reviewrating);
            ratno = itemView.findViewById(R.id.reviewratingno);
            img = itemView.findViewById(R.id.reviewrphoto);

        }
    }
}

