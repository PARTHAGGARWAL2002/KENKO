package com.example.intro_splashscreen_kenko;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Diagnosis extends AppCompatActivity {
    int Age, ind_max;
    double temp;
    double max;
    String gender,c;
    TextView question;
    AdapterConditions adapterC;
    Button b1;
    Button b2;
    Button b3;
    Button b4;
    Button b5,ff;
    Diagnosis current;
    RecyclerView cond;
    TextView condlabel;
    TextView dr;
    TextView l4;
    TextView md;
    TextView reco;
    TextView tri;
    ImageView bkr;
    TextView pro;
    String specialist;
    ArrayList<String> Name = new ArrayList<>();
    ArrayList<Double> perc = new ArrayList<>();
    private ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);

    List<EvidenceItem> list = new ArrayList<>();
    ArrayList<SEvidenceItem> Slist = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_diagnosis);


        current = this;
        ArrayList<SymtomItem> selected = (ArrayList<SymtomItem>) getIntent().getSerializableExtra("Symptoms");
        Age = getIntent().getIntExtra("Age",18);
        gender =  getIntent().getStringExtra("gender");
        Log.e("lxl",selected.size()+"");

        question = findViewById(R.id.textView4);
        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        b5 = findViewById(R.id.button5);
        condlabel = findViewById(R.id.condlabel);
        cond = findViewById(R.id.rec_cond);
        dr = findViewById(R.id.DiagnosticReport);
        l4 = findViewById(R.id.line4);
        md = findViewById(R.id.disease_main);
        reco = findViewById(R.id.Rec);
        tri = findViewById(R.id.tri);
        pro = findViewById(R.id.probability);
        bkr = findViewById(R.id.imreport);
        ff = findViewById(R.id.findder);
        initRecylerView();

        for(int i =0; i<selected.size();i++){
            list.add(
                    new EvidenceItem(selected.get(i).getLine1(),"present","initial")

            );
            Slist.add( new SEvidenceItem(selected.get(i).getLine1(),"present"));
            Log.e("msg","i am in");
        }

        DiagnosisInput input = new DiagnosisInput(

                gender,
                new Age(Age),
                list,
                new Extra(true)
        );
        max=0;

        specialinput sinput = new specialinput(
                gender,
                new SAge(Age),
                Slist

        );
        api(input,sinput);

    }




    public  void api(DiagnosisInput input, specialinput sinput){
        try {
            String jj = new Gson().toJson(input);
            Log.e("pen",jj);

            apiInterface.diagnosis(input).enqueue(new Callback<DiagnosisOutput>() {
                @Override
                public void onResponse(@NotNull Call<DiagnosisOutput> call, @NotNull Response<DiagnosisOutput> response) {
                    Log.e("yo", "We are here");
                    try {
                        if (response.body().conditions.get(0).probability > 0.3) {
                            Log.e("recylerview", "We are in cond here");
                            Name.clear();
                            perc.clear();
                            for (int i = 0; i < response.body().conditions.size(); i++) {
                                Name.add(response.body().conditions.get(i).common_name);
                                temp = (int) (response.body().conditions.get(i).probability * 100);
                                if (temp > max) {
                                    max = temp;
                                    ind_max = i;
                                }

                                String k = (temp) + "";
                                Log.e("pro", k);
                                double str1 = Double.parseDouble(k);
                                perc.add(str1);
                            }
                            Log.e("condition",Name.size()+"");
                            adapterC.notifyDataSetChanged();


                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                    if (response.body().conditions.size() > 0) {
                        c = "";
                        for (int i = 0; i < response.body().conditions.size(); i++) {
                            if (response.body().conditions.get(i).probability > 0.9) {
                                c = response.body().conditions.get(i).common_name;

                            }
                        }
                        if (c.length() != 0) {

                            //remove everything
                            b1.setVisibility(View.GONE);
                            b2.setVisibility(View.GONE);
                            b3.setVisibility(View.GONE);
                            b4.setVisibility(View.GONE);
                            b5.setVisibility(View.GONE);
                            cond.setVisibility(View.GONE);
                            question.setVisibility(View.GONE);
                            condlabel.setVisibility(View.GONE);

                            //making show new stuff
                            dr.setVisibility(View.VISIBLE);
                            l4.setVisibility(View.VISIBLE);
                            md.setVisibility(View.VISIBLE);
                            pro.setVisibility(View.VISIBLE);
                            reco.setVisibility(View.VISIBLE);
                            tri.setVisibility(View.VISIBLE);
                            bkr.setVisibility(View.VISIBLE);
                            ff.setVisibility(View.VISIBLE);

                            apiInterface.specialist(sinput).enqueue(new Callback<specialistoutput>() {
                                @Override
                                public void onResponse(Call<specialistoutput> call, Response<specialistoutput> sresponse) {
                                    specialist = sresponse.body().getRecommendedSpecialist().getNaame();

                                }

                                @Override
                                public void onFailure(Call<specialistoutput> call, Throwable t) {

                                }
                            });
                            ff.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent intent = new Intent(getApplicationContext(),NMainActivity.class);
                                    intent.putExtra("specialist", specialist);
                                    startActivity(intent);
                                }
                            });
                            md.setText(response.body().conditions.get(ind_max).common_name);
                            pro.setText("Probability: " + ((int) (response.body().conditions.get(ind_max).probability*100) + "") + "%");
                            tri.setText(response.body().conditions.get(ind_max).condition_details.hint);
                            return;


                        }
                    }
                    question.setVisibility(View.VISIBLE);
                    question.setText(response.body().question.text);
                    b1.setVisibility(View.GONE);
                    b2.setVisibility(View.GONE);
                    b3.setVisibility(View.GONE);
                    b4.setVisibility(View.GONE);
                    b5.setVisibility(View.GONE);
                    cond.setVisibility(View.GONE);
                    if (response.body().question.items.size() == 1) {
                        b1.setVisibility(View.VISIBLE);
                        b2.setVisibility(View.VISIBLE);
                        b1.setText("Yes");
                        b2.setText("No");
                        b1.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                list.add(new EvidenceItem(response.body().question.items.get(0).id, "present", "initial"));
                                Slist.add(new SEvidenceItem(response.body().question.items.get(0).id, "present"));
                                api(new DiagnosisInput(gender, new Age(Age), list, new Extra(true)), new specialinput(gender,new SAge(Age),Slist));
                            }
                        });
                        b2.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                list.add(new EvidenceItem(response.body().question.items.get(0).id, "absent", "initial"));
                                Slist.add(new SEvidenceItem(response.body().question.items.get(0).id, "absent"));
                                                                api(new DiagnosisInput(gender, new Age(Age), list, new Extra(true)), new specialinput(gender,new SAge(Age),Slist));


                            }
                        });
                    } else {
                        Log.e("options",response.body().question.items.size()+"");
                        if (response.body().question.items.size() >= 1) {
                            b1.setVisibility(View.VISIBLE);
                            b1.setText(response.body().question.items.get(0).name);
                            b1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    list.add(new EvidenceItem(response.body().question.items.get(0).id, "present", "initial"));
                                    Slist.add(new SEvidenceItem(response.body().question.items.get(0).id, "present"));
                                                                    api(new DiagnosisInput(gender, new Age(Age), list, new Extra(true)), new specialinput(gender,new SAge(Age),Slist));

                                }
                            });
                        }
                        if (response.body().question.items.size() >= 2) {
                                  b2.setVisibility(View.VISIBLE);
                            b2.setText(response.body().question.items.get(1).name);
                            b2.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    list.add(new EvidenceItem(response.body().question.items.get(1).id, "present", "initial"));
                                    Slist.add(new SEvidenceItem(response.body().question.items.get(1).id, "present"));
                                                                    api(new DiagnosisInput(gender, new Age(Age), list, new Extra(true)), new specialinput(gender,new SAge(Age),Slist));

                                }
                            });
                        }

                        if (response.body().question.items.size() >= 3) {
                                 b3.setVisibility(View.VISIBLE);
                            b3.setText(response.body().question.items.get(2).name);
                            b3.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    list.add(new EvidenceItem(response.body().question.items.get(2).id, "present", "initial"));
                                    Slist.add(new SEvidenceItem(response.body().question.items.get(2).id, "present"));
                                                                    api(new DiagnosisInput(gender, new Age(Age), list, new Extra(true)), new specialinput(gender,new SAge(Age),Slist));

                                }
                            });
                        }
                        if (response.body().question.items.size() >= 4) {
                                 b4.setVisibility(View.VISIBLE);
                            b4.setText(response.body().question.items.get(3).name);
                            b4.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    list.add(new EvidenceItem(response.body().question.items.get(3).id, "present", "initial"));
                                    Slist.add(new SEvidenceItem(response.body().question.items.get(3).id, "present"));
                                                                    api(new DiagnosisInput(gender, new Age(Age), list, new Extra(true)), new specialinput(gender,new SAge(Age),Slist));

                                }
                            });
                        }
                        if (response.body().question.items.size() >= 5) {
                                     b5.setVisibility(View.VISIBLE);
                            b5.setText(response.body().question.items.get(4).name);
                            b5.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    list.add(new EvidenceItem(response.body().question.items.get(4).id, "present", "initial"));
                                    Slist.add(new SEvidenceItem(response.body().question.items.get(4).id, "present"));
                                                                    api(new DiagnosisInput(gender, new Age(Age), list, new Extra(true)), new specialinput(gender,new SAge(Age),Slist));

                                }
                            });
                        }
                    }


                }

                @Override
                public void onFailure(Call<DiagnosisOutput> call, Throwable t) {
                    t.printStackTrace();
                }
            });
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    private void initRecylerView() {

        GridLayoutManager LayoutManager = new GridLayoutManager(this,2,RecyclerView.VERTICAL,false);
        //View view;
        Toast.makeText(this,Name.size()+","+perc.size(),Toast.LENGTH_SHORT).show();

        cond= findViewById(R.id.rec_cond);
        cond.setLayoutManager(LayoutManager);
        adapterC = new AdapterConditions(Name,perc);
        cond.setAdapter(adapterC);
        cond.setVisibility(View.VISIBLE);
        condlabel.setVisibility(View.VISIBLE);
    }


}
