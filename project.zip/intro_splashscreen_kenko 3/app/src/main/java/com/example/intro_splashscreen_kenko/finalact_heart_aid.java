package com.example.intro_splashscreen_kenko;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class finalact_heart_aid extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finalact_heart_aid);
    }
}