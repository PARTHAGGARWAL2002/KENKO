package com.example.intro_splashscreen_kenko;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class covidresources extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_covidresources);
    }
}