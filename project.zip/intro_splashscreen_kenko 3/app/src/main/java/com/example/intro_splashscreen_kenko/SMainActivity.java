package com.example.intro_splashscreen_kenko;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SMainActivity extends AppCompatActivity {
    public String js;
    public ArrayList<SymtomItem> symp;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private MyAdapter myAdapter;
    public ArrayList<SymtomItem> symp_copy= new ArrayList<>();
    public ArrayList<SymtomItem> selected = new ArrayList<>();
    EditText editText;
    TextView sympL;
    private ImageView del;
    private FloatingActionButton next;
    int Age;
    String gender;
    public void raw()
    {

        try {
            Resources res = getResources();
            InputStream in_s = res.openRawResource(R.raw.symptom);
            BufferedReader reader = new BufferedReader(new InputStreamReader(in_s));
            js="";
            while(true)
            {
                String s = reader.readLine();
                if(s!=null)
                    js=js+s;
                else
                    break;
            }
            Gson gson = new Gson();
            Type type = new TypeToken<List<SymtomItem>>() {}.getType();
            symp = gson.fromJson(js, type);


            Log.e("SMainActivity",symp.size()+"");

        } catch (Exception e) {
            e.printStackTrace();

        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smain);
        raw();
        myAdapter = new MyAdapter(symp_copy, this, new SymptomClick() {
            @Override
            public void onclick(int position) {
                //WHAT HAPPENS ON CLICK
                //Toast.makeText(getApplicationContext(),symp.get(position).getLine1(),Toast.LENGTH_SHORT).show();
                selected.add(symp_copy.get(position));
                updatehint();
                editText.setText("");
            }
        });
        next = (FloatingActionButton) findViewById(R.id.next);
        del = (ImageView) findViewById(R.id.del);
        sympL = (TextView) findViewById(R.id.symtomL2);
        editText = (EditText) findViewById(R.id.searc);
        Age = getIntent().getIntExtra("Age",18);
        gender =  getIntent().getStringExtra("gender");
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String se= s.toString();
                //Toast.makeText(getApplicationContext(),se,Toast.LENGTH_SHORT).show();
                symp_copy.clear();
                for(int i =0;i<symp.size();i++){
                    if(symp.get(i).getCommon_name().contains(se)){
                        symp_copy.add(symp.get(i));
                    }

                }

                myAdapter.notifyDataSetChanged();

            }


            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selected.size()>0) {
                    selected.remove(selected.size() - 1);
                    updatehint();
                }
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selected.size()>0){
                    Intent intent = new Intent(getApplicationContext(),Diagnosis.class);
                    intent.putExtra("Symptoms",selected);
                    intent.putExtra("Age",Age);
                    intent.putExtra("gender",gender);
                    startActivity(intent);
                }
            }
        });
        recyclerView = (RecyclerView) findViewById(R.id.recyler);
        recyclerView.setLayoutManager(new GridLayoutManager(this,2));
        //recyclerView.setHasFixedSize(true);

        recyclerView.setAdapter(myAdapter);






    }
    private void updatehint(){
        String hint = "Selected : ";
        for(int i=0;i<selected.size(); i++){
            hint=hint+selected.get(i).getCommon_name()+",";
        }
        sympL.setText(hint);
    }

}
