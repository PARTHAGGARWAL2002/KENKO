package com.example.intro_splashscreen_kenko;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.shawnlin.numberpicker.NumberPicker;

import java.util.ArrayList;

public class AgeGender extends AppCompatActivity {
    ImageView male;
    ImageView female;
    String gender;
    NumberPicker age;
    int Age;
    // public ArrayList<SymtomItem> selected = new ArrayList<>();
    Button next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_age_gender);
        male = findViewById(R.id.male2);
        female = findViewById(R.id.female2);
        age= (NumberPicker) findViewById(R.id.age);
        Age = 18;

        //ArrayList<SymtomItem> selected = (ArrayList<SymtomItem>) getIntent().getSerializableExtra("Symptoms");


        try {
            age.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
                @Override
                public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                    Age = newVal;
                }
            });
        }catch (NullPointerException ignored){

        }
        //age = findViewById(R.id.age);

        try{
            male.setOnTouchListener(new View.OnTouchListener() {

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    gender="male";

                    male.setPressed(true);
                    female.setPressed(false);
                    return true;
                }
            });
        }catch (NullPointerException ignored){

        }
        try{
            female.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    gender="female";
                    female.setPressed(true);
                    male.setPressed(false);
                    return true;
                }
            });
        }catch (NullPointerException ignored){

        }


        //Log.e("lol",gender);

        next = findViewById(R.id.floatingActionButton2);
        try{
            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getApplicationContext(),SMainActivity.class);
                    intent.putExtra("Age",Age);
                    intent.putExtra("gender",gender);
                    startActivity(intent);
                }
            });
        }catch (NullPointerException ignored){

        }
    }
}