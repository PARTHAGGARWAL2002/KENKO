package com.example.intro_splashscreen_kenko;

import java.io.Serializable;

public class SymtomItem implements Serializable {
    private String id;
    private String type;
    private String name;
    private String common_name;
    public SymtomItem(String line1, String line2, String line3 , String line4) {
        id= line1;
        type = line2;
        name = line3;
        common_name = line4;
    }
    public String getLine1() {
        return id;
    }
    public String getLine2() {
        return type;
    }
    public String getName(){
        return name;
    }
    public String getCommon_name(){
        return common_name;
    }
}

