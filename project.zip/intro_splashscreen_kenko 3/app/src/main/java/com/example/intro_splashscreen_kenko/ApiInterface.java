package com.example.intro_splashscreen_kenko;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

interface ApiInterface {

    @Headers({"App-Id:9d863522", "App-Key:452cde4a346bbdaced3a6439668fe397"})
    @POST("v3/diagnosis")
    Call<DiagnosisOutput> diagnosis(@Body DiagnosisInput input);

    @Headers({"App-Id:9d863522", "App-Key:452cde4a346bbdaced3a6439668fe397"})
    @POST("v3/recommend_specialist")
    Call<specialistoutput> specialist(@Body specialinput sinput);


}
