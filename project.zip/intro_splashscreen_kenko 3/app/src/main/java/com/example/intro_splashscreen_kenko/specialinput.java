package com.example.intro_splashscreen_kenko;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class specialinput {

    @SerializedName("sex")
    String ssex;
    @SerializedName("age")
    SAge Sage;
    @SerializedName("evidence")
    List<SEvidenceItem> SevidenceItems;

    public specialinput( String ssex,SAge age, List<SEvidenceItem> SevidenceItems) {
        this.ssex=ssex;
        this.Sage = age;
        this.SevidenceItems = SevidenceItems;

    }
}

      class SAge {
        @SerializedName("value")
        int value;

        public SAge(int value) {
            this.value = value;
        }
    }

    class SEvidenceItem {
        @SerializedName("id")
        String id;
        @SerializedName("choice_id")
        String choice;


        public SEvidenceItem(String id, String choice) {
            this.id = id;
            this.choice = choice;

        }
    }

