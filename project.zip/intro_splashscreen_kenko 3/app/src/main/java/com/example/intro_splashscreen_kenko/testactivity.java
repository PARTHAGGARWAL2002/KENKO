package com.example.intro_splashscreen_kenko;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class testactivity extends AppCompatActivity  {
    TextView name,rating,address,timing,status,phone;
    ImageView map,rat,mapimg;
    private LocationManager locationManager;
    RecyclerView Reviews;
    String currentLocation;
    String loc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.places_viewlayout);
        mapimg= findViewById(R.id.mapimg);
        name = findViewById(R.id.place_name);
        rating = findViewById(R.id.textrating);
        address = findViewById(R.id.adres);
        timing = findViewById(R.id.timings);
        status = findViewById(R.id.status);
        map = findViewById(R.id.place_image);
        phone = findViewById(R.id.phoneplace);
        rat = findViewById(R.id.imgrating);
        Reviews = findViewById(R.id.reviews);
        loc = getIntent().getStringExtra("loc");
        Log.e("location",loc);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2 * 1000, 1, locationListener);
        }
        else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 12);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 13);
            }
        }


        String placeid = getIntent().getStringExtra("placeid");
        Log.e("Place id",placeid);
        String key = "AIzaSyCycuvCR91gdWd5h0jewwpFgkYL_Xb51Jk";
        String fields = "name,business_status,rating,price_level,formatted_phone_number,formatted_address,opening_hours,review";
        GoogleMapAPI googleMapAPI = APIClientmaps.getClient().create(GoogleMapAPI.class);
        googleMapAPI.getdeatils(placeid,fields,key).enqueue(new Callback<details>() {
            @Override
            public void onResponse(Call<details> call, Response<details> response) {
                name.setText(response.body().getResult().getName());
                //boolean isOpen = response.body().getResult().getOpeningHours().getOpenNow();
//                if(isOpen)
//                    status.setText("OPEN");
//                else
//                    status.setText("CLOSED");
                rating.setText(response.body().getResult().getRating().toString());
                address.setText(response.body().getResult().getFormattedAddress());
                List<String> timings = response.body().getResult().getOpeningHours().getWeekdayText();
                StringBuilder timingText = new StringBuilder();
                for (int i = 0; i < timings.size(); i++) {
                    timingText.append(timings.get(i)).append("\n");
                }
                String finaltimingText = timingText.toString().trim();
                timing.setText(finaltimingText);
                if(response.body().getResult().getRating()<0.5)
                    rat.setImageResource(R.drawable.star0);
                if(response.body().getResult().getRating()<1.5)
                    rat.setImageResource(R.drawable.star1);
                if(response.body().getResult().getRating()<2.5)
                    rat.setImageResource(R.drawable.star2);
                if(response.body().getResult().getRating()<3.5)
                    rat.setImageResource(R.drawable.star3);
                if(response.body().getResult().getRating()<4.3)
                    rat.setImageResource(R.drawable.star4);
                if(response.body().getResult().getRating()<4.7)
                    rat.setImageResource(R.drawable.star4_5);
                else
                    rat.setImageResource(R.drawable.star5);
                if(response.body().getResult().getFormattedPhoneNumber()!=null){
                    phone.setText(" "+response.body().getResult().getFormattedPhoneNumber());
                    Log.e("ph",response.body().getResult().getFormattedPhoneNumber()+"");
                    phone.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(Intent.ACTION_DIAL);
                            intent.setData(Uri.parse("tel:"+response.body().getResult().getFormattedPhoneNumber()));
                            startActivity(intent);
                        }
                    });}
                mapimg.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Uri gmmIntentUri = Uri.parse("google.navigation:q="+loc);
                        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                        mapIntent.setPackage("com.google.android.apps.maps");
                        startActivity(mapIntent);

                    }
                });
                Log.e("reviw",response.body().getResult().getReviews().size()+"");

                reviewadapter reviewAdapter= new reviewadapter(getApplicationContext(),response.body().getResult().getReviews());
                Reviews.setAdapter(reviewAdapter);
                Reviews.setLayoutManager(new LinearLayoutManager(getApplicationContext()));


//                if(response.body().getResult().getOpeningHours().getOpenNow())
//                    status.setText("OPEN");
//                else
//                    status.setText("CLOSED");
//                timing.setText((CharSequence) response.body().getResult().getOpeningHours().getWeekdayText());
//
            }

            @Override
            public void onFailure(Call<details> call, Throwable t) {

            }
        });


    }



    private LocationListener locationListener = new LocationListener()
    {
        @Override
        public void onLocationChanged(@NonNull Location location) {
            currentLocation = location.getLatitude() + "," + location.getLongitude();
            Log.e("lo",loc);
            Glide.with(getApplicationContext()).load("https://maps.googleapis.com/maps/api/staticmap?center="+loc+"&zoom=15&size=600x500&maptype=satellite\n" +
                    "&markers=color:orange%7Clabel:C%7C"+currentLocation+"&markers=scale:2%7Ccolor:yellow%7Clabel:H%7C"+loc+"&key=AIzaSyDA43_Nu-xV3lumlyfnPgOVKfIGv4EAMKk").into(map);

        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(@NonNull String provider) {

        }

        @Override
        public void onProviderDisabled(@NonNull String provider) {

        }

    };}
