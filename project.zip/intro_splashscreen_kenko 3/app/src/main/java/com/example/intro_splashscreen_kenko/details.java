package com.example.intro_splashscreen_kenko;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;


public class details implements Serializable {


    @SerializedName("result")
    private detailResult result;


    public detailResult getResult() {
        return result;
    }

    public void setResult(detailResult result) {
        this.result = result;
    }

}









